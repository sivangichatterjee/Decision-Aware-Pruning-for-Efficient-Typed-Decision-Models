import torch, inspect, time, os
os.environ['HF_HUB_OFFLINE']='1'
from fla.ops import fused_recurrent_gated_delta_rule
from transformers.models.qwen3_5 import modeling_qwen3_5 as Q
torch.manual_seed(0)
device='cuda'
batch,tokens,heads,size=1,321,16,128
q,k,v = [torch.randn((batch,tokens,heads,size),device=device,dtype=torch.float16)*0.1 for _ in range(3)]
g=-torch.rand((batch,tokens,heads),device=device)
b=torch.rand((batch,tokens,heads),device=device,dtype=torch.float16)
with torch.inference_mode():
    expected, expected_state = inspect.unwrap(Q.torch_chunk_gated_delta_rule)(q,k,v,g,b,output_final_state=True,use_qk_l2norm_in_kernel=True)
    print('torch reference',torch.isfinite(expected).all().item(),flush=True)
    for repeat in range(2):
        torch.cuda.synchronize(); t=time.perf_counter()
        actual, state=fused_recurrent_gated_delta_rule(q,k,v,g=g,beta=b,output_final_state=True,use_qk_l2norm_in_kernel=True)
        torch.cuda.synchronize()
        print('fused recurrent',time.perf_counter()-t,'max diff',float((expected-actual).abs().max()),'state max diff',float((expected_state-state).abs().max()),flush=True)
